"""Package adding time expiration to Django REST Framework's auth tokens."""

__all__ = [
    'authentication',
    'models',
    'views'
]

__version__ = '0.1.4'
