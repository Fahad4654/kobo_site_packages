from server.views.view_not_named_view import UsedView


class App1View(UsedView):
    template_name = 'app1/used_in_view.html'

