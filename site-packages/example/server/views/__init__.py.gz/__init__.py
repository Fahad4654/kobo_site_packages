class Class:
    pass