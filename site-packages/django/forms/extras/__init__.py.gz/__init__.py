from django.forms.extras.widgets import SelectDateWidget

__all__ = ['SelectDateWidget']
