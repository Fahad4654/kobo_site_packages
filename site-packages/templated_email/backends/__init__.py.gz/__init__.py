class HeaderNotSupportedException(Exception):
    pass
