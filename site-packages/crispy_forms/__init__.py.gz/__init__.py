# -*- coding: utf-8 -*-

__version__ = '1.6.1'
