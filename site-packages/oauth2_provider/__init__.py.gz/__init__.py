__version__ = '0.9.0'

__author__ = "Massimiliano Pippi & Federico Frenguelli"

VERSION = __version__  # synonym
