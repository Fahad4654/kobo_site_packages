from ._cyordereddict import OrderedDict

from .benchmark.benchmark import benchmark

from ._version import __version__
