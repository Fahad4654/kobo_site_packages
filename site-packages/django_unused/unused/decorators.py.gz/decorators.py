def used_view(View):
    View.is_used = True
    return View
