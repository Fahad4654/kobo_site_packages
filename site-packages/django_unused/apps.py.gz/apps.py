from django.apps import AppConfig


class RockNRollConfig(AppConfig):
    name = 'django_unused'
    verbose_name = "Django Unused"
