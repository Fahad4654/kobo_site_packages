For mainframes, the SPSS I/O libraries need to be downloaded from Bitbucket:

`python -m savReaderWriter.util.download_mainframe_libs`


