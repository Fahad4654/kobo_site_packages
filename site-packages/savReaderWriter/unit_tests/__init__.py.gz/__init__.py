#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os

os.chdir(os.path.dirname(__file__))
os.chdir("..")
